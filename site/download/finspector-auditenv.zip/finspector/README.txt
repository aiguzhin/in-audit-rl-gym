FinSpector — учебная RL-среда для аудита.

Python 3.11+, без зависимостей.
  cd finspector
  python -m examples.01_first_steps

Полная версия: https://github.com/aiguzhin/in-audit-rl-gym
